for epoch in range(args.epochs):
    # Train the model
    model.train()
    for i, (images, labels) in enumerate(train_loader):
        images = images.to(device)
        labels = labels.to(device)

        # Define the closure for optimizer
        def closure():
            # Clear gradients, not be accumulated
            optimizer.zero_grad()
            # Forward pass to get output
            outputs = model(images)
            # Calculate loss: softmax + cross entropy loss
            loss = criterion(outputs, labels)
            # Get gradients
            loss.backward()
            # Return loss
            return loss

        # Get lr and loss
        if args.optimizer == 'sgd' or args.optimizer == 'lbfgs':
            lr = get_lr(optimizer)
            loss = optimizer.step(closure)
        elif args.optimizer == 'sgd_ls' or args.optimizer == 'lbfgs_ls':
            loss, lr = optimizer.step(closure)

        # Compute accuracy for the model
        outputs = model(images)
        _, predicted = torch.max(outputs.data, 1)
        total = labels.size(0)
        correct = (predicted == labels).sum().item()
        train_accuracy = 100 * correct / total
