if i == 0 or (i + 1) % args.print_freq == 0:
        print ("Epoch: [{}][{}/{}]_, \
                Loss: {:.4f}_ \
                Accuracy: {:.2f}_ \
                Learning rate: {:.5f}"
               .format(epoch, i, total_step,
               loss.item(), train_accuracy, lr))
