# CIFAR-10 Train dataset
train_dataset = torchvision.datasets.CIFAR10(root ='Datasets/cifar10/',
                            train = True,
                            transform = transforms.ToTensor(),
                            download = True)
# CIFAR-10 Test dataset
test_dataset = torchvision.datasets.CIFAR10(root ='Datasets/cifar10/',
                           train = False,
                           transform = transforms.ToTensor())
# Train dataset loader
train_loader = torch.utils.data.DataLoader(dataset = train_dataset,
                                           batch_size = args.batch_size,
                                           shuffle = True)
# Test dataset loader
test_loader = torch.utils.data.DataLoader(dataset = test_dataset,
                                          batch_size = args.batch_size,
                                          shuffle = False)
