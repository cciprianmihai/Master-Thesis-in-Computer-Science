# Save the model checkpoint
if args.save_model:
    torch.save(model.state_dict(), args.net+'.pth')
