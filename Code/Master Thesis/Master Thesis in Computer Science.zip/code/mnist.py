# MNIST Train dataset
train_dataset = torchvision.datasets.MNIST(root ='Datasets/mnist/',
                            train = True,
                            transform = transforms.ToTensor(),
                            download = True)
# MNIST Test dataset
test_dataset = torchvision.datasets.MNIST(root ='Datasets/mnist/',
                           train = False,
                           transform = transforms.ToTensor())
# Train dataset loader
train_loader = torch.utils.data.DataLoader(dataset = train_dataset,
                                           batch_size = args.batch_size,
                                           shuffle = True)
# Test dataset loader
test_loader = torch.utils.data.DataLoader(dataset = test_dataset,
                                          batch_size = args.batch_size,
                                          shuffle = False)
