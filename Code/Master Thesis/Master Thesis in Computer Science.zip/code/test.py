# Test the model on test set
  model.eval()
  with torch.no_grad():
      correct = 0
      total = 0
      for images_test, labels_test in test_loader:
          images_test = images_test.to(device)
          labels_test = labels_test.to(device)
          outputs = model(images_test)
          _, predicted = torch.max(outputs.data, 1)
          total += labels_test.size(0)
          correct += (predicted == labels_test).sum().item()
      test_accuracy = 100 * correct / total

      print('Test accuracy: {}_'.format(test_accuracy))
